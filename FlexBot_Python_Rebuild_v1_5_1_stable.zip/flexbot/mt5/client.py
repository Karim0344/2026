import logging
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
import MetaTrader5 as mt5

_TF_MAP = {
    "M1": mt5.TIMEFRAME_M1,
    "M5": mt5.TIMEFRAME_M5,
    "M15": mt5.TIMEFRAME_M15,
    "H1": mt5.TIMEFRAME_H1,
    "H4": mt5.TIMEFRAME_H4,
}

@dataclass
class SymbolDiagnostics:
    symbol: str
    digits: int
    point: float
    spread_points: int
    vol_min: float
    vol_step: float
    vol_max: float
    stops_level: int
    freeze_level: int
    trade_mode: int
    filling_mode: int

def initialize(terminal_path: str = "") -> None:
    """Initialize MT5 IPC bridge.

    - If terminal_path is empty: attach to currently running terminal.
    - If terminal_path is provided but invalid: fallback to no-path initialize.
    - Retries briefly on IPC timeout.
    """
    p = (terminal_path or "").strip()
    use_path = None
    if p:
        if os.path.exists(p):
            use_path = p
        else:
            logging.warning(f'TERMINAL_PATH_INVALID path="{p}" -> falling back to no-path attach')

    for _ in range(6):
        ok = mt5.initialize(path=use_path) if use_path else mt5.initialize()
        if ok:
            return
        err = mt5.last_error()
        if err and int(err[0]) == -10005:
            import time
            time.sleep(1.5)
            continue
        break

    raise RuntimeError(
        f"MT5 initialize failed: {mt5.last_error()}. "
        "Fix: open MetaTrader 5 terminal, log in, keep it running, then start the bot again. "
        "If you have multiple MT5 terminals, set the correct terminal64.exe path in the bot."
    )

def shutdown() -> None:
    try:
        mt5.shutdown()
    except Exception:
        pass

def tf_to_mt5(timeframe: str) -> int:
    if timeframe not in _TF_MAP:
        raise ValueError(f"Unsupported timeframe: {timeframe}")
    return _TF_MAP[timeframe]


def resolve_symbol(symbol: str, auto_resolve: bool = True) -> str:
    """Return a usable symbol name. If symbol not found or has no ticks and auto_resolve,
    attempt to find a close alternative (broker suffixes like XAUUSD#, XAUUSDm, GOLD)."""
    info = mt5.symbol_info(symbol)
    if info is None:
        if not auto_resolve:
            raise RuntimeError(f"Symbol not found in MT5: {symbol}")
        # candidate scan
        all_syms = mt5.symbols_get()
        if not all_syms:
            raise RuntimeError(f"Symbol not found in MT5: {symbol}")
        sym_u = symbol.upper()
        if "XAU" in sym_u or "GOLD" in sym_u:
            cand = [s.name for s in all_syms if ("XAU" in s.name.upper() or "GOLD" in s.name.upper())]
        else:
            base = re.sub(r"[^A-Z0-9]", "", sym_u)
            cand = [s.name for s in all_syms if base in re.sub(r"[^A-Z0-9]", "", s.name.upper())]
        cand = cand[:50]
        # pick first with valid tick
        for name in cand:
            try:
                if mt5.symbol_select(name, True):
                    t = mt5.symbol_info_tick(name)
                    if t and getattr(t,"bid",0)>0 and getattr(t,"ask",0)>0:
                        logging.warning(f"Auto-resolved symbol: {symbol} -> {name}")
                        return name
            except Exception:
                continue
        logging.error(f"Symbol not found: {symbol}. Candidates tried: {cand[:20]}")
        raise RuntimeError(f"Symbol not found in MT5: {symbol}. Check Market Watch exact name.")
    # ensure visible
    if not info.visible:
        mt5.symbol_select(symbol, True)
    # if no tick and auto_resolve, try alternatives with same base
    t = mt5.symbol_info_tick(symbol)
    if (t is None or getattr(t,'bid',0)<=0 or getattr(t,'ask',0)<=0) and auto_resolve:
        all_syms = mt5.symbols_get() or []
        sym_u = symbol.upper()
        if "XAU" in sym_u or "GOLD" in sym_u:
            cand = [s.name for s in all_syms if ("XAU" in s.name.upper() or "GOLD" in s.name.upper())]
        else:
            base = re.sub(r"[^A-Z0-9]", "", sym_u)
            cand = [s.name for s in all_syms if base in re.sub(r"[^A-Z0-9]", "", s.name.upper())]
        cand = cand[:50]
        for name in cand:
            try:
                if mt5.symbol_select(name, True):
                    tt = mt5.symbol_info_tick(name)
                    if tt and getattr(tt,'bid',0)>0 and getattr(tt,'ask',0)>0:
                        logging.warning(f"Auto-resolved symbol (tick): {symbol} -> {name}")
                        return name
            except Exception:
                continue
        # fall through (keep original) and let diagnostics raise better error
    return symbol

def ensure_symbol(symbol: str) -> None:
    info = mt5.symbol_info(symbol)
    if info is None:
        # Suggest likely alternatives (broker suffixes)
        try:
            all_syms = mt5.symbols_get()
            if all_syms:
                cand = [s.name for s in all_syms if ("XAU" in s.name.upper() or "GOLD" in s.name.upper())]
                cand = cand[:20]
                logging.error(f"Symbol not found: {symbol}. Possible gold symbols: {cand}")
        except Exception:
            pass
        raise RuntimeError(
            f"Symbol not found in MT5: {symbol}. "
            "Fix: check exact symbol name in Market Watch (some brokers use suffix like XAUUSD#, XAUUSDm, GOLD)."
        )
    if not info.visible:
        if not mt5.symbol_select(symbol, True):
            raise RuntimeError(f"Could not select symbol: {symbol}")


def get_symbol_diagnostics(symbol: str) -> SymbolDiagnostics:
    # Ensure symbol is available/visible in Market Watch
    symbol = resolve_symbol(symbol, auto_resolve=True)
    info = mt5.symbol_info(symbol)
    if info is None:
        raise RuntimeError(f"Symbol not found in MT5: {symbol}")

    # Tick can be None if no quotes yet (market closed / symbol not subscribed).
    tick = None
    for _ in range(6):
        tick = mt5.symbol_info_tick(symbol)
        if tick is not None and getattr(tick, "bid", 0.0) > 0 and getattr(tick, "ask", 0.0) > 0:
            break
        import time
        time.sleep(0.5)

    if tick is None or getattr(tick, "bid", 0.0) <= 0 or getattr(tick, "ask", 0.0) <= 0:
        raise RuntimeError(
            f"Symbol tick not available: {symbol}. "
            "Fix: in MT5 open Market Watch -> Show All, then click the symbol chart so quotes stream. "
            "Also verify the exact symbol name (some brokers use suffix like XAUUSD#, XAUUSDm, GOLD). "
            "If the market is closed, wait until it opens."
        )

    spread_points = int(round((tick.ask - tick.bid) / info.point)) if info.point else int(getattr(info, "spread", 0))

    # Some MetaTrader5 Python builds expose these as trade_* fields.
    stops_level = getattr(info, "stops_level", None)
    if stops_level is None:
        stops_level = int(getattr(info, "trade_stops_level", 0))
    freeze_level = getattr(info, "freeze_level", None)
    if freeze_level is None:
        freeze_level = int(getattr(info, "trade_freeze_level", 0))

    filling_mode = getattr(info, "filling_mode", None)
    if filling_mode is None:
        filling_mode = int(getattr(info, "trade_fill_mode", 0))
    return SymbolDiagnostics(
        symbol=symbol,
        digits=info.digits,
        point=info.point,
        spread_points=spread_points,
        vol_min=info.volume_min,
        vol_step=info.volume_step,
        vol_max=info.volume_max,
        stops_level=int(stops_level),
        freeze_level=int(freeze_level),
        trade_mode=info.trade_mode,
        filling_mode=int(filling_mode),
    )

def account_equity() -> float:
    ai = mt5.account_info()
    if ai is None:
        raise RuntimeError(f"account_info failed: {mt5.last_error()}")
    return float(ai.equity)

def broker_datetime_utc(symbol: str) -> datetime:
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        return datetime.now(timezone.utc)
    return datetime.fromtimestamp(int(tick.time), tz=timezone.utc)

def copy_rates(symbol: str, timeframe: str, bars: int):
    tf = tf_to_mt5(timeframe)
    rates = mt5.copy_rates_from_pos(symbol, tf, 0, bars)
    return rates

def positions(symbol: str, magic: int | None = None):
    pos = mt5.positions_get(symbol=symbol)
    if pos is None:
        return []
    if magic is None:
        return list(pos)
    return [p for p in pos if int(p.magic) == int(magic)]

def history_deals(from_dt: datetime, to_dt: datetime):
    deals = mt5.history_deals_get(from_dt, to_dt)
    if deals is None:
        return []
    return list(deals)

def round_volume(vol: float, vol_step: float) -> float:
    # round down to step
    if vol_step <= 0:
        return vol
    steps = int(vol / vol_step)
    return round(steps * vol_step, 8)

def get_tick(symbol: str):
    return mt5.symbol_info_tick(symbol)
